
package com.example.bookshop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Book> bookList;
    List<Book> bookList1;
    List<Book> bookList2;
    RecyclerView recyclerView,recyclerView1,recyclerView2;
    RecyclerAdapter adapter,adapter1,adapter2;
    // Linear Layout Manager
    LinearLayoutManager HorizontalLayout,hr1,hrl2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bookList=new ArrayList<>();
        bookList1=new ArrayList<>();
        bookList2=new ArrayList<>();
        bookList.add(new Book("Five Point Someone","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.fivepoint));
        bookList.add(new Book("Half Girlfriend","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.half));
        bookList.add(new Book("Revolution 2020","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.revolution));
        bookList.add(new Book("Oh Yes","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.ohyes));
        bookList.add(new Book("The girl","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.thegirl));
        bookList.add(new Book("Two states","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.twostates));
        bookList.add(new Book("What india","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.what));
        bookList.add(new Book("the World","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.world));


        bookList1.add(new Book("Oh Yes","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.ohyes));
        bookList1.add(new Book("The girl","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.thegirl));
        bookList1.add(new Book("Two states","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.twostates));
        bookList1.add(new Book("What india","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.what));
        bookList1.add(new Book("the World","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.world));
        bookList1.add(new Book("Five Point Someone","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.fivepoint));
        bookList1.add(new Book("Half Girlfriend","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.half));

        bookList2.add(new Book("Oh Yes","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.ohyes));
        bookList2.add(new Book("The girl","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.thegirl));
        bookList2.add(new Book("Two states","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.twostates));
        bookList2.add(new Book("What india","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.what));
        bookList2.add(new Book("the World","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.world));
        bookList2.add(new Book("Oh Yes","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.ohyes));
        bookList2.add(new Book("The girl","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.thegirl));
        bookList2.add(new Book("Two states","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.twostates));
        bookList2.add(new Book("What india","Novel","Young india","Rs. 212","Chetan Bhagat",R.drawable.what));
        bookList2.add(new Book("the World","Novel","yound generation","Rs.199","Chetan Bhagat",R.drawable.world));

        recyclerView=findViewById(R.id.recycler);
        recyclerView1=findViewById(R.id.recycler1);
        recyclerView2=findViewById(R.id.recycler2);

        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        recyclerView1.setLayoutManager(new GridLayoutManager(this,3));
        recyclerView2.setLayoutManager(new GridLayoutManager(this,3));

        adapter=new RecyclerAdapter(this,bookList);
        adapter1=new RecyclerAdapter(this,bookList1);
        adapter2=new RecyclerAdapter(this,bookList2);

        // Set Horizontal Layout Manager
        // for Recycler view
        HorizontalLayout = new LinearLayoutManager(MainActivity.this,
                LinearLayoutManager.HORIZONTAL,
                false);
        recyclerView.setLayoutManager(HorizontalLayout);
        recyclerView.setAdapter(adapter);
        hr1 = new LinearLayoutManager(
                MainActivity.this,
                LinearLayoutManager.HORIZONTAL,
                false);
        hrl2=new LinearLayoutManager(MainActivity.this,LinearLayoutManager.HORIZONTAL,false);
        recyclerView1.setLayoutManager(hr1);
        recyclerView1.setAdapter(adapter1);
        recyclerView2.setLayoutManager(hrl2);
        recyclerView2.setAdapter(adapter2);

    }
}